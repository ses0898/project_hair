class PagesController < ApplicationController
  def home
    @customers = User.all
    ##@designers = User.find(params[:usergrade])
  end
end
